﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Threading;
using System.Windows.Media.Animation;

namespace SistemaPetAraponga
{
    /// <summary>
    /// Lógica interna para FrmCadastro.xaml
    /// </summary>
    public partial class FrmCadastro : Window
    {
        string data;

        public FrmCadastro()
        {
            InitializeComponent();
        }

        

        private void BtnProdutos_Click(object sender, RoutedEventArgs e)
        {
            FrmProdutos frm = new FrmProdutos();
            frm.Show();
            this.Close();
        }

        private void BtnVoltar_Click(object sender, RoutedEventArgs e)
        {
            FrmMenu frm = new FrmMenu();
            frm.Show();
            this.Close();
        }

        private void BtnFuncionarios_Click(object sender, RoutedEventArgs e)
        {
            frmFuncionarios frm = new frmFuncionarios();
            frm.Show();
            this.Close();
        }

        private void BtnFornecedores_Click(object sender, RoutedEventArgs e)
        {
            frmFornecedores frm = new frmFornecedores();
            frm.Show();
            this.Close();
        }

        private void BtnCliente_Click(object sender, RoutedEventArgs e)
        {
            FrmCliente frm = new FrmCliente();
            frm.Show();
            this.Close();
            
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            

            
            {
                LblHora.Content = DateTime.Now.ToString("HH:mm");
                LblData.Content = DateTime.Now.ToString("dd/MM/yyyy");
            }
            
            
            
            
        }

        private void Window_MouseMove(object sender, MouseEventArgs e)
        {
            LblHora.Content = DateTime.Now.ToString("HH:mm");
            LblData.Content = DateTime.Now.ToString("dd/MM/yyyy");
        }

        private void BtnVoltar_MouseEnter(object sender, MouseEventArgs e)
        {
            BtnVoltar.Width = 43;
            BtnVoltar.Height = 41;

           /* Image rotateImage = new Image()
            {
                Stretch = Stretch.Uniform,
                Source = new BitmapImage(new Uri("pack://siteoforigin:,,,/img/voltar.jpg")),
                RenderTransform = new RotateTransform()
            };
            Image opacityImage = new Image()
            {
                Stretch = Stretch.Uniform,
                Source = new BitmapImage(new Uri("pack://siteoforigin:,,,/img/voltar.jpg"))
            };
            
            LayoutRoot.Children.Add(rotateImage);
            LayoutRoot.Children.Add(opacityImage);

            Grid.SetColumn(opacityImage, 1);

            Storyboard storyboard = new Storyboard();
            storyboard.Duration = new Duration(TimeSpan.FromSeconds(10.0));
            DoubleAnimation rotateAnimation = new DoubleAnimation()
            {
                From = 0,
                To = 360,
                Duration = storyboard.Duration
            };
            DoubleAnimation opacityAnimation = new DoubleAnimation()
            {
                From = 1.0,
                To = 0.0,
                BeginTime = TimeSpan.FromSeconds(5.0),
                Duration = new Duration(TimeSpan.FromSeconds(5.0))
            };

            Storyboard.SetTarget(rotateAnimation, rotateImage);
            Storyboard.SetTargetProperty(rotateAnimation, new PropertyPath("(UIElement.RenderTransform).(RotateTransform.Angle)"));
            Storyboard.SetTarget(opacityAnimation, opacityImage);
            Storyboard.SetTargetProperty(opacityAnimation, new PropertyPath("Opacity"));

            storyboard.Children.Add(rotateAnimation);
            storyboard.Children.Add(opacityAnimation);

            Resources.Add("Storyboard", storyboard);

            Button button = new Button()
            {
                Content = "Begin"
            };
            button.Click += button_Click;

            Grid.SetRow(button, 1);
            Grid.SetColumnSpan(button, 2);

            LayoutRoot.Children.Add(button);*/
        }

        /*void button_Click(object sender, RoutedEventArgs e)
        {
            ((Storyboard)Resources["Storyboard"]).Begin();
        }*/

        private void BtnVoltar_MouseLeave(object sender, MouseEventArgs e)
        {
            BtnVoltar.Width = 37;
            BtnVoltar.Height = 36;
        }
    }

    
}
