﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SistemaPetAraponga
{
    /// <summary>
    /// Lógica interna para FrmProdutos.xaml
    /// </summary>
    public partial class FrmProdutos : Window
    {
        string nome, tipo, marca, grupo, subgrupo, local;
        double valorCompra, lucro, valorVenda, qtde;
        int codigo;
        public FrmProdutos()
        {
            InitializeComponent();
        }

        private void BtnSair_Click(object sender, RoutedEventArgs e)
        {
            FrmCadastro frm = new FrmCadastro();
            frm.Show();
            this.Close();
        }

        private void TxtTipodoProduto_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtTipodoProduto.Text != "")
                {
                    tipo = (TxtTipodoProduto.Text);

                    LblTipodoProduto.Foreground = new SolidColorBrush(Colors.Black);

                    TxtMarca.Focus();

                }
                else
                {
                    MessageBox.Show("Favor preencher o campo Tipo de Produto ");
                    LblTipodoProduto.Foreground = new SolidColorBrush(Colors.Red);//Mudar a cor do texto da label 
                }
            }
        }

        private void BtnSair_MouseEnter(object sender, MouseEventArgs e)
        {
            BtnSair.FontSize = 22;
        }

        private void BtnSair_MouseLeave(object sender, MouseEventArgs e)
        {
            BtnSair.FontSize = 12;
        }

        private void TxtNomedoProduto_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtNomeProduto.Text != "")
                {
                    nome = (TxtNomeProduto.Text); //Variavel nome recebe o conteudo da caixa de texto

                    LblNomedoProduto.Foreground = new SolidColorBrush(Colors.Black);//Mudar a cor do texto da label para o padrao

                    TxtTipodoProduto.Focus();       //Focar na proxima TextBox


                }
                else
                {
                    MessageBox.Show("Favor preencher o campo Nome do Produto ");
                    //Mensagem para preencher o nome
                    LblNomedoProduto.Foreground = new SolidColorBrush(Colors.Red);//Mudar a cor do texto da label 
                }
            }
        }

        

        private void TxtMarca_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtMarca.Text != "")
                {
                    marca = (TxtMarca.Text);

                    LblMarca.Foreground = new SolidColorBrush(Colors.Black);

                    TxtGrupo.Focus();
                }
                else
                {
                    MessageBox.Show("Favor preencher o campo Marca ");

                    LblMarca.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtGrupo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtGrupo.Text != "")
                {
                    grupo = (TxtGrupo.Text);

                    LblGrupo.Foreground = new SolidColorBrush(Colors.Black);

                    TxtSubGrupo.Focus();
                }
                else
                {
                    MessageBox.Show("Favor preencher o campo Grupo ");

                    LblGrupo.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtSubGrupo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtSubGrupo.Text != "")
                {
                    subgrupo = (TxtSubGrupo.Text);

                    LblSubGrupo.Foreground = new SolidColorBrush(Colors.Black);

                    TxtValordeCompra.Focus();
                }
                else
                {
                    MessageBox.Show("Favor preencher o campo SubGrupo ");

                    LblSubGrupo.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtValordeCompra_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtValordeCompra.Text != "")
                {
                    valorCompra = double.Parse(TxtValordeCompra.Text);

                    LblValordeCompra.Foreground = new SolidColorBrush(Colors.Black);

                    TxtPorcentagemdeLucro.Focus();
                }
                else
                {
                    MessageBox.Show("Favor preencher o campo Valor de Compra ");

                    LblValordeCompra.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtPorcentagemdeLucro_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtPorcentagemdeLucro.Text != "")
                {
                    lucro = double.Parse(TxtPorcentagemdeLucro.Text);

                    LblPorcentagemdelucro.Foreground = new SolidColorBrush(Colors.Black);

                    TxtLocalizacao.Focus();
                }
                else
                {
                    MessageBox.Show("Favor preencher o campo %Lucro ");

                    LblPorcentagemdelucro.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtLocalizacao_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtLocalizacao.Text != "")
                {
                    local = (TxtLocalizacao.Text);

                    LblLocalizacao.Foreground = new SolidColorBrush(Colors.Black);

                    TxtQuantidadeemEstoque.Focus();
                }
                else
                {
                    MessageBox.Show("Favor preencher o campo Localização ");

                    LblLocalizacao.Foreground = new SolidColorBrush(Colors.Red);
                }

            }
        }

        private void TxtQuantidadeemEstoque_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtQuantidadeemEstoque.Text != "")
                {
                    qtde = double.Parse(TxtQuantidadeemEstoque.Text);

                    LblQuantidadeemEstoque.Foreground = new SolidColorBrush(Colors.Black);

                    BtnSalvar.Focus();
                }
                else
                {
                    MessageBox.Show("Favor preencher o campo Quantidade em Estoque");

                    LblQuantidadeemEstoque.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        
    }
}
