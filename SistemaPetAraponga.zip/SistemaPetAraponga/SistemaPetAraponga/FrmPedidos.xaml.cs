﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SistemaPetAraponga
{
    /// <summary>
    /// Lógica interna para FrmPedidos.xaml
    /// </summary>
    public partial class FrmPedidos : Window
    {

        string nomeProduto, endereco, complemento, bairro, cidade, UF, email, site, CEP, telefone, celular, horaPedido, dataPedido, nomeComprador, numeroPedido;
        int numero;

        private void CmbUF_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (CmbUF.Text != "")
                {
                    UF = (CmbUF.Text);

                    LblUF.Foreground = new SolidColorBrush(Colors.Black);
                    TxtCEP.IsEnabled = true;
                    TxtCEP.Focus();
                }
                else
                {
                    MessageBox.Show("Favor preencher o campo UF ");

                    LblUF.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtCEP_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtCEP.Text != "")
                {
                    CEP = (TxtCEP.Text);

                    LblCEP.Foreground = new SolidColorBrush(Colors.Black);
                    TxtEmail.IsEnabled = true;
                    TxtEmail.Focus();

                }
                else
                {
                    MessageBox.Show("Favor preencher o campo CEP ");

                    LblCEP.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtEmail_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtEmail.Text != "")
                {
                    email = (TxtEmail.Text);

                    LblEmail.Foreground = new SolidColorBrush(Colors.Black);
                    TxtTelefone.IsEnabled = true;
                    TxtTelefone.Focus();
                }
                else
                {
                    MessageBox.Show("Favor preencher o campo E-mail ");

                    LblEmail.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtTelefone_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtTelefone.Text != "")
                {
                    telefone = (TxtTelefone.Text);

                    LblTelefone.Foreground = new SolidColorBrush(Colors.Black);
                    TxtCelular.IsEnabled = true;
                    TxtCelular.Focus();
                }
                else
                {
                    MessageBox.Show("Favor preencher o campo Telefone ");

                    LblTelefone.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtCelular_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtCelular.Text != "")
                {
                    celular = (TxtCelular.Text);

                    LblCelular.Foreground = new SolidColorBrush(Colors.Black);
                    BtnSalvar.IsEnabled = true;
                    BtnSalvar.Focus();
                }
                else
                {
                    MessageBox.Show("Favor preencher o campo Celular ");

                    LblCelular.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void BtnNovo_Click(object sender, RoutedEventArgs e)
        {
            TxtNumeroPedido.IsEnabled = true;
            TxtNumeroPedido.Focus();
            TxtNumeroPedido.Text = DateTime.Now.ToShortDateString();

            BtnNovo.IsEnabled = false;
            BtnLimpar.IsEnabled = true;
        }

        private void BtnSair_MouseEnter(object sender, MouseEventArgs e)
        {
            BtnSair.FontSize = 22;
        }

        private void BtnSair_MouseLeave(object sender, MouseEventArgs e)
        {
            BtnSair.FontSize = 12;
        }

        private void BtnLimpar_Click(object sender, RoutedEventArgs e)
        {
            TxtNumeroPedido.Text = "";
            TxtNomeProduto.Text = "";
            TxtDataPedido.Text = "";
            TxtHoraPedido.Text = "";
            TxtNomeComprador.Text = "";
            TxtEndereco.Text = "";
            TxtNumero.Text = "";
            TxtComplemento.Text = "";
            TxtBairro.Text = "";
            TxtCidade.Text = "";
            CmbUF.Text = "";
            TxtCEP.Text = "";
            TxtEmail.Text = "";
            TxtTelefone.Text = "";
            TxtCelular.Text = "";
            
            

            TxtNumeroPedido.IsEnabled = false;
            TxtNomeProduto.IsEnabled = false;
            TxtDataPedido.IsEnabled = false;
            TxtHoraPedido.IsEnabled = false;
            TxtNomeComprador.IsEnabled = false;
            TxtEndereco.IsEnabled = false;
            TxtNumero.IsEnabled = false;
            TxtComplemento.IsEnabled = false;
            TxtBairro.IsEnabled = false;
            TxtCidade.IsEnabled = false;
            CmbUF.IsEnabled = false;
            TxtCEP.IsEnabled = false;
            TxtEmail.IsEnabled = false;
            TxtTelefone.IsEnabled = false;
            TxtCelular.IsEnabled = false;
            
            



            
            nomeProduto = null;
            dataPedido = null;
            horaPedido = null;            
            nomeComprador = null;            
            endereco = null;
            numero = 0;
            complemento = null;
            bairro = null;
            cidade = null;
            UF = null;
            CEP = null;
            telefone = null;
            celular = null;
            email = null;
            site = null;

            BtnSalvar.IsEnabled = false;
            BtnLimpar.IsEnabled = false;
            BtnNovo.IsEnabled = true;
            BtnNovo.Focus();
        }

        private void TxtCidade_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtCidade.Text != "")
                {
                    cidade = (TxtCidade.Text);

                    LblCidade.Foreground = new SolidColorBrush(Colors.Black);
                    CmbUF.IsEnabled = true;
                    CmbUF.Focus();
                }
                else
                {
                    MessageBox.Show("Favor preencher o campo Cidade ");

                    LblCidade.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtBairro_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtBairro.Text != "")
                {
                    bairro = (TxtBairro.Text);

                    LblBairro.Foreground = new SolidColorBrush(Colors.Black);
                    TxtCidade.IsEnabled = true;
                    TxtCidade.Focus();
                }
                else
                {
                    MessageBox.Show("Favor preencher o campo Bairro ");

                    LblBairro.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtComplemento_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtComplemento.Text != "")
                {
                    complemento = (TxtComplemento.Text);

                    LblComplemento.Foreground = new SolidColorBrush(Colors.Black);
                    TxtBairro.IsEnabled = true;
                    TxtBairro.Focus();
                }
                else
                {
                    MessageBox.Show("Favor preencher o campo Complemento ");

                    LblComplemento.Foreground = new SolidColorBrush(Colors.Red);

                }


            }
        }

        private void TxtNumero_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtNumero.Text != "")
                {
                    numero = int.Parse(TxtNumero.Text);

                    LblNumero.Foreground = new SolidColorBrush(Colors.Black);
                    TxtComplemento.IsEnabled = true;
                    TxtComplemento.Focus();
                }
                else
                {
                    MessageBox.Show("Favor preencher o campo Número ");

                    LblNumero.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtEndereco_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {


                if (TxtEndereco.Text != "")
                {
                    endereco = (TxtEndereco.Text);

                    LblEndereco.Foreground = new SolidColorBrush(Colors.Black);
                    TxtNumero.IsEnabled = true;
                    TxtNumero.Focus();
                }
                else
                {
                    MessageBox.Show("Favor preencher o campo Endereço ");

                    LblEndereco.Foreground = new SolidColorBrush(Colors.Red);

                }
            }
        }

        private void TxtNomeComprador_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtNomeComprador.Text != "")
                {
                    nomeComprador = (TxtNomeComprador.Text);

                    TxtNomeComprador.Foreground = new SolidColorBrush(Colors.Black);
                    TxtEndereco.IsEnabled = true;
                    TxtEndereco.Focus();
                }
                else
                {
                    MessageBox.Show("Favor preencher o campo Nome do Comprador ");

                    LblNomeComprador.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtDataPedido_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtDataPedido.Text != "")
                {
                    dataPedido = (TxtDataPedido.Text);

                    TxtDataPedido.Foreground = new SolidColorBrush(Colors.Black);
                    TxtHoraPedido.IsEnabled = true;
                    TxtHoraPedido.Focus();
                }
                else
                {
                    MessageBox.Show("Favor preencher o campo Data do Pedido ");

                    LblDataPedido.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtHoraPedido_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtHoraPedido.Text != "")
                {
                    horaPedido = (TxtHoraPedido.Text);

                    TxtHoraPedido.Foreground = new SolidColorBrush(Colors.Black);
                    TxtNomeComprador.IsEnabled = true;
                    TxtNomeComprador.Focus();
                }
                else
                {
                    MessageBox.Show("Favor preencher o campo Hora do Pedido ");

                    LblHoraPedido.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtNomeProduto_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtNomeProduto.Text != "")
                {
                    nomeProduto = (TxtNomeProduto.Text);

                    TxtNomeProduto.Foreground = new SolidColorBrush(Colors.Black);
                    TxtDataPedido.IsEnabled = true;
                    TxtDataPedido.Focus();
                }
                else
                {
                    MessageBox.Show("Favor preencher o campo Nome Produto ");

                    LblNomeProduto.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        
        public FrmPedidos()
        {
            InitializeComponent();
        }

        private void BtnSair_Click(object sender, RoutedEventArgs e)
        {
            FrmMenu frm = new FrmMenu();
            frm.Show();
            this.Close();
        }

        private void BtnSalvar_Click(object sender, RoutedEventArgs e)
        {
            modelos mo = new modelos();
            cone db = new cone();

            mo.NumeroPedido = numeroPedido;
            mo.NomeProduto = nomeProduto;
            mo.DataPedido = dataPedido;
            mo.HoraPedido = horaPedido;
            mo.NomeComprador = nomeComprador;
            mo.Endereco = endereco;
            mo.Numero = numero;
            mo.Complemento = complemento;
            mo.Bairro = bairro;
            mo.Cidade = cidade;
            mo.Uf = UF;
            mo.Cep = CEP;
            mo.Email = email;
            mo.Telefone = telefone;
            mo.Celular = celular;
            
            

            db.cadpedidos(mo);

            MessageBox.Show("Pedido cadastrado com sucesso!");

            TxtNumeroPedido.Text = "";
            TxtNomeProduto.Text = "";
            TxtDataPedido.Text = "";
            TxtHoraPedido.Text = "";
            TxtNomeComprador.Text = "";
            TxtEndereco.Text = "";
            TxtNumero.Text = "";
            TxtComplemento.Text = "";
            TxtBairro.Text = "";
            TxtCidade.Text = "";
            CmbUF.Text = "";
            TxtCEP.Text = "";
            TxtEmail.Text = "";
            TxtTelefone.Text = "";
            TxtCelular.Text = "";
            
            
        }

        private void TxtNumeroProduto_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtNumeroPedido.Text != "")
                {
                    numeroPedido = (TxtNumeroPedido.Text);

                    TxtNumeroPedido.Foreground = new SolidColorBrush(Colors.Black);
                    TxtNomeProduto.IsEnabled = true;
                    TxtNomeProduto.Focus();
                }
                else
                {
                    MessageBox.Show("Favor preencher o campo Número do Produto ");

                    LblNumeroPedido.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }
    }
}
