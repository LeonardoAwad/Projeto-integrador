﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaPetAraponga
{
    class modelos
    {
        private int nCodigo;
        private string nNome;
        private string nNomeProduto;
        private string nNomeComprador;
        private string nEndereco;
        private int nNumero;
        private string nNumeroPedido;
        private string nComplemento;
        private string nBairro;
        private string nCidade;
        private string nUf;
        private string nCep;
        private string nTelefone;
        private string nCelular;
        private string nTelefone2;
        private string nCelular2;
        private string nRepresentante;
        private string nFornecedor;
        private string nEspecialidade;
        private string nDataCadastro;
        private string nDataAdmissao;
        private string nDataPedido;
        private string nHoraPedido;
        private string nDataDemissao;
        private string nDataInicio;
        private string nDataTermino;
        private string nEmail;
        private string nSite;
        private string nDiaSemana;
        private string nCargo;
        private string nProduto;
        private string nTipoProduto;
        private string nMarca;
        private string nGrupo;
        private string nSubGrupo;
        private double nValorCompra;
        private double nLucro;
        private double nValorVenda;
        private string nLocalizacao;
        private double nQtdeEstoque;

        public int Codigo
        {
            get { return nCodigo; }
            set { nCodigo = value; }
        }

        public string Nome
        {
            get { return nNome; }
            set { nNome = value; }
        }
        public string NomeProduto
        {
            get { return nNomeProduto; }
            set { nNomeProduto = value; }
        }

        public string NomeComprador
        {
            get { return nNomeComprador; }
            set { nNomeComprador = value; }
        }

        public string Endereco
        {
            get { return nEndereco; }
            set { nEndereco = value; }
        }

        public int Numero
        {
            get { return nNumero; }
            set { nNumero = value; }
        }

        public string NumeroPedido
        {
            get { return nNumeroPedido; }
            set { nNumeroPedido = value; }
        }

        public string Complemento
        {
            get { return nComplemento; }
            set { nComplemento = value; }
        }

        public string Bairro
        {
            get { return nBairro; }
            set { nBairro = value; }
        }

        public string Cidade
        {
            get { return nCidade; }
            set { nCidade = value; }
        }

        public string Uf
        {
            get { return nUf; }
            set { nUf = value; }
        }

        public string Cep
        {
            get { return nCep; }
            set { nCep = value; }
        }

        public string Telefone
        {
            get { return nTelefone; }
            set { nTelefone = value; }
        }

        public string Celular
        {
            get { return nCelular; }
            set { nCelular = value; }
        }

        public string Telefone2
        {
            get { return nTelefone2; }
            set { nTelefone2 = value; }
        }

        public string Celular2
        {
            get { return nCelular2; }
            set { nCelular2 = value; }
        }

        public string Representante
        {
            get { return nRepresentante; }
            set { nRepresentante = value; }
        }

        public string Fornecedor
        {
            get { return nFornecedor; }
            set { nFornecedor = value; }
        }

        public string Especialidade
        {
            get { return nEspecialidade; }
            set { nEspecialidade = value; }
        }

        public string DataCadastro
        {
            get { return nDataCadastro; }
            set { nDataCadastro = value; }
        }

        public string DataAdmissao
        {
            get { return nDataAdmissao; }
            set { nDataAdmissao = value; }
        }


        public string DataDemissao
        {
            get { return nDataDemissao; }
            set { nDataDemissao = value; }
        }

        public string DataPedido
        {
            get { return nDataPedido; }
            set { nDataPedido = value; }
        }

        public string HoraPedido
        {
            get { return nHoraPedido; }
            set { nHoraPedido = value; }
        }


        public string DataInicio
        {
            get { return nDataInicio; }
            set { nDataInicio = value; }
        }

        public string DataTermino
        {
            get { return nDataTermino; }
            set { nDataTermino = value; }
        }

        public string Email
        {
            get { return nEmail; }
            set { nEmail = value; }
        }

        public string Site
        {
            get { return nSite; }
            set { nSite = value; }
        }

        public string DiaSemana
        {
            get { return nDiaSemana; }
            set { nDiaSemana = value; }
        }


        public string Cargo
        {
            get { return nCargo; }
            set { nCargo = value; }
        }

        public string Produto
        {
            get { return nProduto; }
            set { nProduto = value; }
        }

        public string TipoProduto
        {
            get { return nTipoProduto; }
            set { nTipoProduto = value; }
        }


        public string Marca
        {
            get { return nMarca; }
            set { nMarca = value; }
        }


        public string Grupo
        {
            get { return nGrupo; }
            set { nGrupo = value; }
        }

        public string SubGrupo
        {
            get { return nSubGrupo; }
            set { nSubGrupo = value; }
        }

        public double ValorCompra
        {
            get { return nValorCompra; }
            set { nValorCompra = value; }
        }

        public double Lucro
        {
            get { return nLucro; }
            set { nLucro = value; }
        }

        public double ValorVenda
        {
            get { return nValorVenda; }
            set { nValorVenda = value; }
        }

        public string Localizacao
        {
            get { return nLocalizacao; }
            set { nLocalizacao = value; }
        }

        public double QtdeEstoque
        {
            get { return nQtdeEstoque; }
            set { nQtdeEstoque = value; }
        }












    }

}
