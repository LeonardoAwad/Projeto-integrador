﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace SistemaPetAraponga
{
    class cone
    {
        private MySqlConnection conexao;

        public void cadcliente(modelos mo)// mo é so a abreviação pra nao ficar escrevendo  o bagulho inteiro taokey
        {
            string caminho = "SERVER=localhost;USER=root;DATABASE=pet";

            try
            {
                conexao = new MySqlConnection(caminho);
                conexao.Open();
                string inserir = "INSERT INTO cliente(dataCadastro,nomeCompleto,endereco,numero,complemento,bairro,cidade,uf,cep,telefone,celular,email,site)values('"
                    + mo.DataCadastro + "','"
                    + mo.Nome + "','"
                    + mo.Endereco + "','"
                    + mo.Numero + "','"
                    + mo.Complemento + "','"
                    + mo.Bairro + "','"
                    + mo.Cidade + "','"
                    + mo.Uf + "','"
                    + mo.Cep + "','"
                    + mo.Telefone + "','"
                    + mo.Celular + "','"
                    + mo.Email + "','"
                    + mo.Site + "')";

                MySqlCommand comandos = new MySqlCommand(inserir, conexao);
                comandos.ExecuteNonQuery();

                conexao.Close();

            }

            catch (Exception ex)
            {
                throw new Exception("Erro de comandos: " + ex.Message);
            }
        }
        public void cadfornecedores(modelos mo)// mo é so a abreviação pra nao ficar escrevendo  o bagulho inteiro taokey
        {
            string caminho = "SERVER=localhost;USER=root;DATABASE=pet";

            try
            {
                conexao = new MySqlConnection(caminho);
                conexao.Open();
                string inserir = "INSERT INTO fornecedores(datacadastro,nomecompleto,endereco,numero,complemento,bairro,cidade,uf,cep,telefone,celular,email,site,representante,telefoneRepre,celularRepre)values('"
                     + mo.DataCadastro + "','"
                    + mo.Nome + "','"
                    + mo.Endereco + "','"
                    + mo.Numero + "','"
                    + mo.Complemento + "','"
                    + mo.Bairro + "','"
                    + mo.Cidade + "','"
                    + mo.Uf + "','"
                    + mo.Cep + "','"
                    + mo.Telefone + "','"
                    + mo.Celular + "','"
                    + mo.Email + "','"
                    + mo.Site + "','"
                    + mo.Representante + "','"
                    + mo.Telefone2 + "','"
                    + mo.Celular2 + "')";

                MySqlCommand comandos = new MySqlCommand(inserir, conexao);
                comandos.ExecuteNonQuery();

                conexao.Close();

            }

            catch (Exception ex)
            {
                throw new Exception("Erro de comandos: " + ex.Message);
            }
        }
        public void cadfuncionarios(modelos mo)// mo é so a abreviação pra nao ficar escrevendo  o bagulho inteiro taokey
        {
            string caminho = "SERVER=localhost;USER=root;DATABASE=pet";

            try
            {
                conexao = new MySqlConnection(caminho);
                conexao.Open();
                string inserir = "INSERT INTO funcionarios(dataadmissao,nomecompleto,endereco,numero,complemento,bairro,cidade,uf,cep,telefone,celular,email,cargo,datademissao)values('"
                    + mo.DataAdmissao + "','"
                    + mo.Nome + "','"
                    + mo.Endereco + "','"
                    + mo.Numero + "','"
                    + mo.Complemento + "','"
                    + mo.Bairro + "','"
                    + mo.Cidade + "','"
                    + mo.Uf + "','"
                    + mo.Cep + "','"
                    + mo.Telefone + "','"
                    + mo.Celular + "','"
                    + mo.Email + "','"
                    + mo.Cargo + "','"
                    + mo.DataDemissao + "')";

                MySqlCommand comandos = new MySqlCommand(inserir, conexao);
                comandos.ExecuteNonQuery();

                conexao.Close();

            }

            catch (Exception ex)
            {
                throw new Exception("Erro de comandos: " + ex.Message);
            }
        }

        public void cadpedidos(modelos mo)// mo é so a abreviação pra nao ficar escrevendo  o bagulho inteiro taokey
        {
            string caminho = "SERVER=localhost;USER=root;DATABASE=pet";

            try
            {
                conexao = new MySqlConnection(caminho);
                conexao.Open();
                string inserir = "INSERT INTO pedidos(numeroPedido,nomeProduto,dataPedido,horaPedido,nomeComprador,endereco,numero,complemento,bairro,cidade,uf,cep,email,telefone,celular)values('"
                    + mo.NumeroPedido + "','"
                    + mo.NomeProduto + "','"
                    + mo.DataPedido + "','"
                    + mo.HoraPedido + "','"
                    + mo.NomeComprador + "','"
                    + mo.Endereco + "','"
                    + mo.Numero + "','"
                    + mo.Complemento + "','"
                    + mo.Bairro + "','"
                    + mo.Cidade + "','"
                    + mo.Uf + "','"
                    + mo.Cep + "','"
                    + mo.Email + "','"
                    + mo.Telefone + "','"
                    + mo.Celular + "')";
                




                MySqlCommand comandos = new MySqlCommand(inserir, conexao);
                comandos.ExecuteNonQuery();

                conexao.Close();

            }

            catch (Exception ex)
            {
                throw new Exception("Erro de comandos: " + ex.Message);
            }
        }
    }
}
