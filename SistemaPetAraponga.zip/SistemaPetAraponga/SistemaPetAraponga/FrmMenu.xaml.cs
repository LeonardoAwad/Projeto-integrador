﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SistemaPetAraponga
{
    /// <summary>
    /// Lógica interna para FrmMenu.xaml
    /// </summary>
    public partial class FrmMenu : Window
    {
        public FrmMenu()
        {
            InitializeComponent();
        }

        

        private void BtnSair1_Click(object sender, RoutedEventArgs e)
        {

            FrmEncerrar frm = new FrmEncerrar();
            frm.Show();
            this.Close();
            
        }

        private void BtnCadastro_Click(object sender, RoutedEventArgs e)
        {
            FrmCadastro frm = new FrmCadastro();
            frm.Show();
            this.Close();
        }

        private void BtnSobre_Click(object sender, RoutedEventArgs e)
        {
            FrmSobre frm = new FrmSobre();
            frm.Show();
            this.Close();

        }

        private void BtnPedidos_Click(object sender, RoutedEventArgs e)
        {
            FrmPedidos frm = new FrmPedidos();
            frm.Show();
            this.Close();
        }

        /*private void BtnCadastro_MouseEnter(object sender, MouseEventArgs e)
        {
            BtnCadastro.Background = new SolidColorBrush(Colors.Black);
        }
        private void BtnCadastro_MouseHover(object sender, MouseEventArgs e)
        {
            BtnCadastro.Background = new SolidColorBrush(Colors.Black);
        }*/
    }
}
