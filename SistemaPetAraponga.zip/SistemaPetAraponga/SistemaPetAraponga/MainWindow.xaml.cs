﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading; 

namespace SistemaPetAraponga
{
    /// <summary>
    /// Interação lógica para MainWindow.xam
    /// </summary>
    public partial class MainWindow : Window
    {
        int i = 0, verificacao;
        string usuario, senha;
        public MainWindow()
        {
            
            InitializeComponent();
            TxtUsuario.Focus();
        }

        private void BtnSair_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void TxtUsuario_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.Key == Key.Enter)
            {
                usuario = TxtUsuario.Text;
                PwbSenha.IsEnabled = true;
                PwbSenha.Focus();
            }
        }

        private void PwbSenha_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                senha = PwbSenha.Password;
                BtnEntrar.IsEnabled = true;
                BtnEntrar.Focus();
            }
        }

        private void BtnEntrar_Click(object sender, RoutedEventArgs e)
        {
            Thread.Sleep(100);// esperar 1 segundo
            PgbLogin.Value = 0;
            i = 0;
            Task.Run(() =>
            {
                while (i < 100)
                {
                    i++;
                    Thread.Sleep(50);
                    this.Dispatcher.Invoke(() =>
                    {
                        PgbLogin.Value = i;
                        while (i == 100)
                        {
                            if (verificacao< 1)
                            {
                                if (usuario == "ADMLeo" && senha == "anao")
                                {
                                    Hide();
                                    FrmMenu frm = new FrmMenu();
                                    frm.Show();
                                    verificacao++;
                                    break;
                                }
                                else if (usuario == "ADMZE" && senha == "8877" || usuario == "ADMMINE" && senha == "1503")
                                {
                                    Hide();
                                    FrmMenu frm = new FrmMenu();
                                    frm.Show();
                                    verificacao++;
                                    break;

                                }
                                else
                                {
                                    MessageBox.Show("Favor preencher o usuário ou a senha corretamente");
                                    TxtUsuario.Clear();
                                    PwbSenha.Clear();
                                    TxtUsuario.Focus();
                                    PgbLogin.Value = 0;
                                    PwbSenha.IsEnabled = false;
                                    BtnEntrar.IsEnabled = false;

                                }
                            }
                            
                            break;
                        }
                    });
                }
            });
        }
    }
}
