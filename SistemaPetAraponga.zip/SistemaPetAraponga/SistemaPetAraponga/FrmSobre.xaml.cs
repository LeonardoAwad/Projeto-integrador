﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SistemaPetAraponga
{
    /// <summary>
    /// Lógica interna para FrmSobre.xaml
    /// </summary>
    public partial class FrmSobre : Window
    {
        public FrmSobre()
        {
            InitializeComponent();
        }

        private void BtnSair_Click(object sender, RoutedEventArgs e)
        {
            FrmMenu frm = new FrmMenu();
            frm.Show();
            this.Close();
        }

        private void BtnSair_MouseEnter(object sender, MouseEventArgs e)
        {
            BtnSair.FontSize = 22;
        }

        private void BtnSair_MouseLeave(object sender, MouseEventArgs e)
        {
            BtnSair.FontSize = 12;
        }
    }
}
