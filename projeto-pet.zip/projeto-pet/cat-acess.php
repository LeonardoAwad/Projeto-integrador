<article class="FundoCat">	
			<article class="ImgAcess2">
		
			<article class="CatAcess">
				<img src="img/cat.png" alt="Dog">
				<hr>
			</article>	
				
				
			<section class="galeriaAcess"><!--GALERIA-->
			
			<img src="img/CatAcess1.png" alt="Galeria 1">
			<img src="img/CatAcess2.png" alt="Galeria 2">
			<img src="img/CatAcess3.png" alt="Galeria 3">
			<img src="img/CatAcess4.png" alt="Galeria 4">
			<img src="img/CatAcess1.png" alt="Galeria 5">
			<img src="img/CatAcess2.png" alt="Galeria 6">
			<img src="img/CatAcess3.png" alt="Galeria 7">
				</section>
				</article>
			</article>