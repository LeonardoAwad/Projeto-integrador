// JavaScript Document

$('.banner').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplay: true,
  dots: true,
  autoplaySpeed: 2000,
});

$('.galeriaAcess').slick({
  slidesToShow: 6,
  slidesToScroll: 1,
  autoplay: true,
  autoplaySpeed: 2000,
});

$('.galeria').slick({
  slidesToShow: 6,
  slidesToScroll: 1,
  autoplay: true,
  autoplaySpeed: 2000,
});


$('.cachorro').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplay: true,
  dots: true,
  autoplaySpeed: 2000,
});

$('.FundoCurio2').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplay: true,
  dots: true,
  autoplaySpeed: 2300,
});


new WOW().init();

document.querySelector(".abrir-menu").onclick = function (){
	console.log("ABRIR MENU");
	
	document.documentElement.classList.add("menu-ativo");
}

document.querySelector(".fechar-menu").onclick = function (){
	console.log("FECHAR MENU");
	
	document.documentElement.classList.remove("menu-ativo");

}

window.onscroll = function(){
	
	let top = window.pageYOffset || document.documentElement.scrollTop;
	
	if(top > 10){
		console.log(top);
			document.getElementById("topo-fixo").classList.add("menu-fixo");
		
	   
	}else{
		
		console.log(top);
			document.getElementById("topo-fixo").classList.remove("menu-fixo");
				
}
	
}
