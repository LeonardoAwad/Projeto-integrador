<header><!--COMEÇO CABEÇALHO-->
<div>				
<article class="home">
<img src="img/NovoLogo.png" alt="Logo Araponga"> 
				
<button class="abrir-menu"></button>
					
</article>
</div>
</header><!--FIM CABEÇALHO-->