<footer class="rodape">
			<div>
				<article class="rodapeLogo mexer">
					<img src="img/LogoRodape.png" alt="Logo Rodape">
				</article>
				<p>Rua Pedro Soares de Andrade, 267</p>
				<p>São Miguel Pta. - São Paulo</p>
				<p>(11)2956-7106 / 2033-1745</p>
				
				<section class="zap mexer">
						<article><a href="https://www.whatsapp.com/?lang=pt_br" target="_blank">
								<h2><span>DiskRações:</span>(11) 93205-0302</h2>
							<img src="img/svg/whatsapp.svg" alt="WhatsApp"></a>
						</article>
				</section>

				 <article class="rodapeSocial mexer">
					<a href="https://www.facebook.com/arapongapet/" target="_blank"><img src="img/svg/face.svg" alt="Facebook"></a>
					<a href="https://www.instagram.com/novaarapongapet/" target="_blank"><img src="img/svg/insta.svg" alt="Instagram"></a>
				</article>
			</div>
</footer>