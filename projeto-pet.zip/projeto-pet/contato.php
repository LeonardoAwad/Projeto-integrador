<!doctype html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width">
		<meta name="Keywords" content="Pet, cachorro, Animais, Gatos">
		<title>Pet-shop Araponga</title>
	</head>
		<link rel="stylesheet" href="css/reset.css">
		
		<link rel="stylesheet" type="text/css" href="css/slick.css">
		<link rel="stylesheet" type="text/css" href="css/slick-theme.css">
		
	
	
		<!-- ESTILO CSS-->
		<link rel="stylesheet" type="text/css" href="css/animate.css">
	
	
	
	
		<!-- LITY-->
		<link rel="stylesheet" type="text/css" href="css/lity.css">
	
		<link rel="stylesheet" href="css/estilo-pet.css">
		<body class="menu">
		
			<?php require_once("home.php"); ?>
		
			<?php require_once("menu.php"); ?>
			
			<section class="mapa">
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3658.9731921461484!2d-46.43839768440767!3d-23.49747506512255!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce63de576751d1%3A0x1573d03a4c1a8adc!2sPet+Shop+Araponga!5e0!3m2!1spt-BR!2sbr!4v1555358181870!5m2!1spt-BR!2sbr" width="100%" height="600" frameborder="0" style="border:0" allowfullscreen></iframe>
			
			</section>
			
			<section class="form site">
				
				<article>
					<form action="#" method="post">
					<legend>Contato</legend>
						<div>
							<input name="nome" placeholder="Digite seu nome: " type="tel">
						</div>
						<div>
						<input name="email" placeholder="Digite seu email:" type="email" required>
						</div>
						<div>
						<input name="fone" placeholder="Digite seu telefone:" type="tel">
						</div>
						<div>
						<textarea name="mens" placeholder="Digite sua mensagem:" rows="10" cols="30"></textarea>
						</div>
						<div>
						<input type="submit" value="Enviar"> 
						</div>
					
					
					</form>
				
				</article>
			
			
			
			</section>
		
			<?php require_once("galeria.php"); ?>
		
			<?php require_once("rodape.php"); ?>
			
		
		
			<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
			<script type="text/javascript" src="js/slick.js"></script>
			<script type="text/javascript" src="js/wow.js"></script>	
			<script type="text/javascript" src="js/lity.js"></script>
	
		
			<script type="text/javascript" src="js/animacao.js"></script>
		  </body>
</html>