<article class="FundoDog">
			<article class="ImgAcess">
			<article class="DogAcess">
				<img src="img/dog.png" alt="Dog">
				<hr>
			</article>	
				
				
			<section class="galeriaAcess"><!--GALERIA-->
			
			<img src="img/DogAcess.jpg" alt="Galeria 1">
			<img src="img/DogAcess.jpg" alt="Galeria 2">
			<img src="img/DogAcess.jpg" alt="Galeria 3">
			<img src="img/DogAcess.jpg" alt="Galeria 4">
			<img src="img/DogAcess.jpg" alt="Galeria 5">
			<img src="img/DogAcess.jpg" alt="Galeria 6">
			<img src="img/DogAcess.jpg" alt="Galeria 7">
				</section>
			
				</article>
			</article>
			<!--fim dog-->
		
			<!--CAT-->
			<article class="FundoCat">	
			<article class="ImgAcess2">
		
			<article class="CatAcess">
				<img src="img/cat.png" alt="Dog">
				<hr>
			</article>	
				
				
			<section class="galeriaAcess"><!--GALERIA-->
			
			<img src="img/CatAcess1.png" alt="Galeria 1">
			<img src="img/CatAcess2.png" alt="Galeria 2">
			<img src="img/CatAcess3.png" alt="Galeria 3">
			<img src="img/CatAcess4.png" alt="Galeria 4">
			<img src="img/CatAcess1.png" alt="Galeria 5">
			<img src="img/CatAcess2.png" alt="Galeria 6">
			<img src="img/CatAcess3.png" alt="Galeria 7">
				</section>
				</article>
			</article>
		
			<!--FIM CAT-->
			
			<!--Pass-->
			<article class="FundoPass">	
			<article class="ImgAcess4">
		
			<article class="PassAcess">
				<img src="img/pas.png" alt="P">
				<hr>
			</article>	
				
				
			<section class="galeriaAcess"><!--GALERIA-->
			
			<img src="img/PassAcess.jpg" alt="Galeria 1">
			<img src="img/PassAcess2.jpg" alt="Galeria 2">
			<img src="img/PassAcess3.jpg" alt="Galeria 3">
			<img src="img/PassAcess4.jpg" alt="Galeria 4">
			<img src="img/PassAcess5.jpg" alt="Galeria 5">
			<img src="img/PassAcess6.jpg" alt="Galeria 6">
			<img src="img/PassAcess.jpg" alt="Galeria 7">
				</section>
				</article>
			</article>
		
			<!--FIM Pass-->


			<!--Hamster-->
			<article class="FundoHam">	
			<article class="ImgAcess3">
		
			<article class="HamAcess">
				<img src="img/hamster.png" alt="Hamster">
				<hr>
			</article>	
				
				
			<section class="galeriaAcess"><!--GALERIA-->
			
			<img src="img/HamAcess.jpg" alt="Galeria 1">
			<img src="img/HamAcess2.jpg" alt="Galeria 2">
			<img src="img/HamAcess3.jpg" alt="Galeria 3">
			<img src="img/HamAcess4.jpg" alt="Galeria 4">
			<img src="img/HamAcess5.jpg" alt="Galeria 5">
			<img src="img/HamAcess6.jpg" alt="Galeria 6">
			<img src="img/HamAcess7.jpg" alt="Galeria 7">
				</section>
				</article>
			</article>
		
			<!--FIM Hamster-->






		
		
			<!--FIM ACESSORIOS-->