<article class="FundoDog">
			<article class="ImgAcess">
			
			<article class="DogAcess">
				<img src="img/dog.png" alt="Dog">
				<hr>
			</article>	
				
				
			<section class="galeriaAcess"><!--GALERIA-->
			
			<img src="img/DogAcess.jpg" alt="Galeria 1">
			<img src="img/DogAcess.jpg" alt="Galeria 2">
			<img src="img/DogAcess.jpg" alt="Galeria 3">
			<img src="img/DogAcess.jpg" alt="Galeria 4">
			<img src="img/DogAcess.jpg" alt="Galeria 5">
			<img src="img/DogAcess.jpg" alt="Galeria 6">
			<img src="img/DogAcess.jpg" alt="Galeria 7">
				</section>
			
				</article>
			</article>