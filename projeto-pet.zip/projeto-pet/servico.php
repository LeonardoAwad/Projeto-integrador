<!doctype html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width">
		<meta name="Keywords" content="Pet, cachorro, Animais, Gatos">
		<title>Pet-shop Araponga</title>
	</head>
		<link rel="stylesheet" href="css/reset.css">
		
		<link rel="stylesheet" type="text/css" href="css/slick.css">
		<link rel="stylesheet" type="text/css" href="css/slick-theme.css">
		
	
	
		<!-- ESTILO CSS-->
		<link rel="stylesheet" type="text/css" href="css/animate.css">
	
	
	
	
		<!-- LITY-->
		<link rel="stylesheet" type="text/css" href="css/lity.css">
	
		<link rel="stylesheet" href="css/estilo-pet.css">
		<body class="menu">
		
			<?php require_once("home.php"); ?>
		
			<?php require_once("menu.php"); ?>
		
			<?php require_once("banner.php"); ?>

		
		
			<?php require_once("galeria.php"); ?>
		
			<?php require_once("rodape.php"); ?>
			
		
		
			<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
			<script type="text/javascript" src="js/slick.js"></script>
			<script type="text/javascript" src="js/wow.js"></script>	
			<script type="text/javascript" src="js/lity.js"></script>
	
		
			<script type="text/javascript" src="js/animacao.js"></script>
		  </body>
</html>