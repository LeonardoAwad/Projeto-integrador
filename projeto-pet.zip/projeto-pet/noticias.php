<section class="texto"><!--DEPOIMENTO-->
				
				<div class="menu fundo">
					
					<article class="estrela fundo"><img class="animated  rotateIn "src="img/Estrela.png" alt="Estrela"></article>
					
					
			
					
					<article class="texto1">
					  
						<article><!--DEPOIMENTO 1-->
							<img src="img/Magnus.png" alt="imagem">
							<h4>Titulo</h4>
							<p>Lorem Ipsum sobreviveu não só a cinco séculos, como também ao salto para a editoração eletrônica, permanecendo essencialmente inalterado Lorem Ipsum sobreviveu não só a cinco séculos, como também ao salto para a editoração eletrônica...</p>
							<a href="#">Leia mais</a>
						</article><!--FIM 1-->
						
						<article><!--DEPOIMENTO 2-->
							<img src="img/Magnus.png" alt="imagem">
							<h4>Titulo</h4>
							<p>Lorem Ipsum sobreviveu não só a cinco séculos, como também ao salto para a editoração eletrônica, permanecendo essencialmente inalterado Lorem Ipsum sobreviveu não só a cinco séculos, como também ao salto para a editoração eletrônica... </p>
							<a href="#">Leia mais</a>
						</article><!--FIM 2-->
						
						<article><!--DEPOIMENTO 3-->
							<img src="img/Magnus.png" alt="imagem">
							<h4>Titulo</h4>
							<p>Lorem Ipsum sobreviveu não só a cinco séculos, como também ao salto para a editoração eletrônica, permanecendo essencialmente inalterado Lorem Ipsum sobreviveu não só a cinco séculos, como também ao salto para a editoração eletrônica...</p>
							<a href="#">Leia mais</a>
						</article><!--FIM 3-->
						
						<article><!--DEPOIMENTO 4-->
							<img src="img/Magnus.png" alt="imagem">
							<h4>Titulo</h4>
							<p>Lorem Ipsum sobreviveu não só a cinco séculos, como também ao salto para a editoração eletrônica, permanecendo essencialmente inalterado Lorem Ipsum sobreviveu não só a cinco séculos, como também ao salto para a editoração eletrônica...</p>
							<a href="#">Leia mais</a>
						</article><!--FIM 4-->
					
	
					</article>
					
				</div>
		</section><!--FIM DEPOIMENTO-->