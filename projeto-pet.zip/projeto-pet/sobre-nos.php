<section class="sobre">
			
			
<div class="sobreUM">
				
<article>
<h2> SOBRE ARAPONGA</h2>
	
<p> somo a nova araponga  Lorem Ipsum sobreviveu não só a cinco séculos, como também ao salto para a editoração eletrônica, permanecendo essencialmente inalterado Lorem Ipsum sobreviveu não só a cinco séculos, como também ao salto para a editoração eletrônica, permanecendo essencialmente inalterado Lorem Ipsum sobreviveu não só a cinco séculos, como também ao salto para a editoração eletrônica...somo a nova araponga  Lorem Ipsum sobreviveu não só a cinco séculos, como também ao salto para a editoração eletrônica, permanecendo essencialmente inalterado Lorem Ipsum sobreviveu não só a cinco séculos, como também ao salto para a editoração eletrônica, permanecendo essencialmente inalterado Lorem Ipsum sobreviveu não só a cinco séculos, como também ao salto para a editoração eletrônica... </p>
</article>
				
<article>
<img src="img/sobre-araponga2.jpg" alt="Pet-Shop Araponga">
</article>
				
</div>
</section>