<article class="FundoGaleria">
		<section class="galeria"><!--GALERIA-->
			
			<img src="img/Galeria.png" alt="Galeria 1">
			<img src="img/Pedigree-Logo.jpg" alt="Galeria 2">
			<img src="img/Galeria.png" alt="Galeria 3">
			<img src="img/Pedigree-Logo.jpg" alt="Galeria 4">
			<img src="img/Galeria.png" alt="Galeria 5">
			<img src="img/Pedigree-Logo.jpg" alt="Galeria 6">
			<img src="img/Galeria.png" alt="Galeria 7">
			
			
		</section><!--FIM GALERIA-->
</article>