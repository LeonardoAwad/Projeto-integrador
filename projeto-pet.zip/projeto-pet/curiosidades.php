
<section class="depoimento"><!--DEPOIMENTO-->
			
			
	<div>
				
		<article class="FundoCurio">
				
			<img src="img/Curiosidades.jpg" alt="Curiosidades">
				
				
		</article>
				
		<article class="FundoCurio2">
			
			<img src="img/Dog1.jpg" alt="Dog">
			<img src="img/Cat1.jpg" alt="Cat">
			<img src="img/Pass1.jpg" alt="Pass">
					
		</article>
				
				
	</div>
</section>