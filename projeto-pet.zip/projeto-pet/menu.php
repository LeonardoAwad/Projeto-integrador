<section id="topo-fixo"> <!--####MENU#####-->
			<div class="menu topo">
				
					<nav>
			
						<button class="fechar-menu"></button>
						<ul>
							<li>
								<a href="index.php">
									
									<span class="icon iconHome icon iconHome animated infinite pulse delay-1s"></span>
									<span>HOME</span>
								
								</a>
							</li><!--  FIM "HOME" Item da lista-->
							
							<li>
								<a href="sobre.php">
									
									<span class="icon iconSobre icon iconHome animated infinite  pulse delay-1s"></span>
									<span>SOBRE</span>
									
								</a>
							</li><!-- FIM SOBRE-->
							
							<li>
								<a href="servico.php">
									
									<span class="icon iconServico icon iconHome animated infinite  pulse delay-1s"></span>
									<span>SERVIÇO</span> 
							
								</a>
							</li><!-- FIM SERVIÇO-->
							
							<li>
								<a href="acessorios.php">
									
									<span class="icon iconAcessorios icon iconHome animated infinite  pulse delay-1s"></span>
									<span>ACESSÓRIOS</span>
									
								</a>
							</li><!--FIM ACESSORIOS-->
							
							<li>
								<a href="gato.php">
									
									<span class="icon iconGato icon iconHome animated infinite  pulse delay-1s"></span>
									<span>GATO</span>
									
								</a>
							</li><!--FIM GATO-->
							
							<li>
								<a href="cachorro.php">
									
									<span class="icon iconCachorro icon iconHome animated infinite  pulse delay-1s"></span>
									<span>CACHORRO</span>
									
								</a>
							</li><!--FIM CACHORRO-->
							
							<li>
								<a href="outros.php">
									<span class="icon iconOutros icon iconHome animated infinite pulse delay-1s"></span>
									<span>OUTROS</span>
								</a>
							</li><!--OUTROS-->
							
							<li>
								<a href="contato.php">
									
									<span class="icon iconContato icon iconHome animated infinite  pulse delay-1s"></span>
									<span>CONTATO</span>
									
								
								</a>
							</li><!--FIM CONTATO-->
						
						</ul><!--FIM OUTROS-->

					</nav>
			</div>
			</section>