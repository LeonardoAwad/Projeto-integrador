<section class="banner"><!--BANNER-->
	<img  src="img/Banner1.png" alt="banner cachorro 1">
	<img  src="img/Banner2.png" alt="banner cachorro 2">
	<img  src="img/Banner3.png" alt="banner cachorro 3">
	<img  src="img/Banner4.png" alt="banner gato 1">
	<img  src="img/Banner5.png" alt="banner cachorro 4">
					
</section><!--FIM BANNER-->